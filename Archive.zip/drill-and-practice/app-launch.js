import { app } from "./app.js";

app.listen({ port: 7777 });
