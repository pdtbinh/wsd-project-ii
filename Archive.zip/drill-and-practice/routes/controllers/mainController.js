const showMain = async ({ response, render, state }) => {
  render("main.eta")
};

export { showMain };
