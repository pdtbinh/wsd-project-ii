import { Router } from "../deps.js";
import * as mainController from "./controllers/mainController.js";
import * as questionController from "./controllers/questionController.js";
import * as optionController from "./controllers/optionController.js";
import {
  loginUser,
  registerUser,
  showLoginForm,
  showRegistrationForm,
} from "./controllers/authenticationController.js";
import {
  deleteTopic,
  postTopic,
  showTopic,
  showTopics,
} from "./controllers/topicController.js";

const router = new Router();

router.get("/", mainController.showMain);

router.get("/topics/:id/questions/:qId", questionController.showQuestion);
router.get("/topics/:id/questions", questionController.showQuestions);

router.get("/topics/:id", showTopic);
router.get("/topics", showTopics);

router.post("/topics/:id/questions:qId/options", optionController.postOption);

router.post("/topics/:id/questions", questionController.postQuestion);
router.post("/topics/:id/delete", deleteTopic);
router.post("/topics", postTopic);

//router.get("/quiz", accountController.showQuiz);

router.get("/auth/register", showRegistrationForm);
router.post("/auth/register", registerUser);
router.get("/auth/login", showLoginForm);
router.post("/auth/login", loginUser);

export { router };
