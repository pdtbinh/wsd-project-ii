import { sql } from "../database/database.js";

const deleteQuestionAnswerOptions = async (questionId) => {
  await sql`DELETE FROM question_answer_options WHERE question_id = ${ questionId }`;
};

export { deleteQuestionAnswerOptions };
