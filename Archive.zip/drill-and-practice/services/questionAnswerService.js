import { sql } from "../database/database.js";

const deleteQuestionAnswers = async (questionId) => {
  await sql`DELETE FROM question_answers WHERE question_id = ${questionId}`;
};

export { deleteQuestionAnswers };
