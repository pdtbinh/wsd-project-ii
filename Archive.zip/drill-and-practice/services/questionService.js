import { sql } from "../database/database.js";

const findQuestionsByTopic = async (topicId) => {
  return await sql`SELECT * FROM questions WHERE topic_id = ${topicId}`;
};

const deleteQuestionsByTopic = async (topicId) => {
  await sql`DELETE FROM questions WHERE topic_id = ${topicId}`;
};

export { findQuestionsByTopic, deleteQuestionsByTopic };
